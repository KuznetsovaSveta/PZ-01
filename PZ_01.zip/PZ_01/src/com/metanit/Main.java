package com.metanit;

public class Main {
    public static void main(String[] args) {
        System.out.println("Первая программа:");
        System.out.println("Hello Java!");

        System.out.println("\nВторая программа:");
        double a = 3;
        double b = 4;
        double c = 0;
        c = Math.sqrt (a * a + b * b);
        System.out.println ("c = " + c);
    }
}

